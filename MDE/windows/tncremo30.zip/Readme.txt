TNCremo v3.0 Build 375

Data transfer software for HEIDENHAIN controls.

Daten�bertragungs-Software f�r HEIDENHAIN Steuerungen. 


Changes from previous version:
------------------------------
Please find details in the online help chapter "What's new"


�nderungen gegen�ber der Vorg�ngerversion:
------------------------------------------
Details finden Sie in der Online-Hilfe im Kapitel "Was ist neu"


Installation notes:
-------------------
- Please extract all files from the archive into the
  same folder, then start the installation.

Installationshinweise:
----------------------
- Bitte extrahieren Sie alle Dateien aus dem Archiv 
  in ein tempor�res Verzeichnis und starten Sie dann 
  die Installation durch Ausf�hren von setup.exe


Software: 332180
Dialogsprachen: cs/da/de/en/es/fi/fr/it/nl/pl/sv
OS: Microsoft Windows(r) XP/Vista/7/8
Datum: 11.03.2014

Software: 332180
Dialog languages: cs/da/de/en/es/fi/fr/it/nl/pl/sv
OS: MS Windows(r) XP/Vista/7/8
Date: 03/11/2014